<?php
/**
 * Security file to prevent direct access
 */

// Silence is golden.
